# CampusQuery

CampusQuery is a lightweight academic PDF question-answering system using hybrid Retrieval-Augmented Generation (RAG). It combines PyMuPDF, Sentence Transformers, FAISS semantic retrieval, BM25 lexical retrieval, hybrid ranking, FLAN-T5 generation, and Streamlit.

## Architecture

PDF -> PyMuPDF -> page-aware chunks -> SentenceTransformer -> FAISS + BM25 -> hybrid ranking -> grounded FLAN-T5 -> answer + page evidence

## Final Version 1 behavior

- Keeps page-level metadata for evidence traceability.
- Uses dense semantic retrieval and BM25 lexical retrieval.
- Normalizes retrieval scores before hybrid ranking.
- Uses alpha=0.65 by default.
- Sends only the highest-ranked evidence to the generator.
- Uses deterministic FLAN-T5 generation.
- Requires one direct, grounded answer rather than a copied heading or bullet list.
- Rejects very short/invalid generations and uses an evidence-grounded fallback.
- Refuses to guess when the uploaded PDF does not contain enough information.
- Displays retrieved evidence, page number, and dense/BM25/hybrid scores.
- Detects image-only/scanned PDFs that have no usable text layer.

## Windows setup

Use Python 3.11. A virtual environment is recommended.

```powershell
py -3.11 -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If Windows blocks `pip.exe` or `streamlit.exe`, continue using `python -m pip` and `python -m streamlit` as shown above.

## Demo

1. Upload a searchable academic PDF.
2. Click **Build / Rebuild Index**.
3. Ask a question whose answer is present in the PDF.
4. Read the single generated answer.
5. Expand **Retrieved evidence** to verify the supporting pages.

Example question for the CampusQuery research paper:

`What is RAG evaluation?`

## Limitations

Version 1 requires a searchable text PDF. Scanned/image-only documents need OCR. Tables, diagrams, mathematical expressions, and poor PDF extraction may reduce retrieval quality. The generator can also reproduce errors present in the source document.
